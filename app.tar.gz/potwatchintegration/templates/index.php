<?php

declare(strict_types=1);

use OCP\Util;

Util::addScript(OCA\PotwatchIntegration\AppInfo\Application::APP_ID, 'main');

?>

<div id="potwatchintegration"></div>
